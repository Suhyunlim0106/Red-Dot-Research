/* VV notes: highlights, comments, page notes and body edits for one page section.
   GitHub Pages build: data stays in this browser (localStorage); export/import moves it between browsers. */
window.VVAnnot = function (ROOT, PID) {
  'use strict';
  if (!ROOT) return { destroy: function () {} };
  var DEAD = false, LISTEN = [];
  function on(t, ev, fn, opt) { t.addEventListener(ev, fn, opt); LISTEN.push([t, ev, fn, opt]); }
  var CTX = 40, MAXQ = 2000;
  var notes = {};            // id -> note
  var store = null;          // backend
  var me = { id: null };
  var userNs = null;
  var readOnly = false;
  var names = {};
  var edits = {};            // id -> body edit
  var estore = null;         // backend for body edits
  var editing = false;

  // ---------- small helpers ----------
  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function btn(label, cls, fn) { var b = el('button', 'vv-btn ' + (cls || ''), label); b.type = 'button'; b.addEventListener('click', function (ev) { ev.preventDefault(); ev.stopPropagation(); fn(ev); }); return b; }
  function uid() { return 'n' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function fmt(ts) { try { var d = new Date(ts); return d.getFullYear() + '.' + (d.getMonth() + 1) + '.' + d.getDate() + ' ' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); } catch (e) { return ''; } }
  function isUI(n) { while (n && n !== ROOT) { if (n.nodeType === 1 && (n.classList.contains('vv-ui') || n.tagName === 'SCRIPT' || n.tagName === 'STYLE')) return true; n = n.parentNode; } return false; }

  // ---------- body edit helpers ----------
  var OK_TAG = { A: ['href', 'target', 'rel', 'class'], SUP: ['class', 'id'], SUB: [], B: [], STRONG: [], I: [], EM: [], BR: [], SPAN: ['class'], CODE: [] };
  function cleanNode(src, dst) {
    for (var c = src.firstChild; c; c = c.nextSibling) {
      if (c.nodeType === 3) { dst.appendChild(document.createTextNode(c.nodeValue)); continue; }
      if (c.nodeType !== 1) continue;
      var allow = OK_TAG[c.tagName];
      if (!allow) { cleanNode(c, dst); continue; }
      var e = document.createElement(c.tagName.toLowerCase());
      allow.forEach(function (a) {
        var v = c.getAttribute(a); if (v == null) return;
        if (a === 'href' && !/^(https?:\/\/|#|[\w\-.\/]+\.html(#[\w\-]*)?$)/i.test(v)) return;
        e.setAttribute(a, v);
      });
      if (e.tagName === 'A' && /^https?:/i.test(e.getAttribute('href') || '')) { e.setAttribute('target', '_blank'); e.setAttribute('rel', 'noopener'); }
      cleanNode(c, e); dst.appendChild(e);
    }
    return dst;
  }
  function sanitize(html) {
    var tpl = document.createElement('template'); tpl.innerHTML = String(html || '').slice(0, 20000);
    var out = document.createElement('div'); cleanNode(tpl.content, out);
    return out.innerHTML.replace(/\u00a0/g, ' ').trim();
  }
  function sig(s) { s = String(s || '').replace(/\s+/g, ' ').trim(); var h = 5381; for (var i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + '.' + s.length; }
  var EDIT_SEL = 'p, li, h1, h2, h3, h4, td, th, dd, dt';
  if (!ROOT.__vv) {
    var bl = Array.prototype.filter.call(ROOT.querySelectorAll(EDIT_SEL), function (b) {
      return !(b.closest && b.closest('.vv-ui, nav, .ptoc, details.mnav-all')) && !b.querySelector('p, li, h1, h2, h3, h4, td, th, dd, dt, ul, ol, div, table, figure, section, dl') && b.textContent.trim();
    });
    ROOT.__vv = { B: bl, O: bl.map(function (b) { return sanitize(b.innerHTML); }), S: bl.map(function (b) { return sig(b.textContent); }) };
  }
  var BLOCKS = ROOT.__vv.B, ORIG = ROOT.__vv.O, OSIG = ROOT.__vv.S;

  // ---------- text map of <main> ----------
  function textNodes() {
    var out = [], w = document.createTreeWalker(ROOT, NodeFilter.SHOW_TEXT, { acceptNode: function (n) { return isUI(n.parentNode) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } });
    var n, pos = 0;
    while ((n = w.nextNode())) { var L = n.nodeValue.length; if (L) { out.push({ node: n, start: pos, end: pos + L }); pos += L; } }
    return out;
  }
  function fullText(map) { return map.map(function (m) { return m.node.nodeValue; }).join(''); }
  function offsetOf(map, node, off) {
    if (node.nodeType !== 3) {               // element boundary -> first text node at/after it
      var child = node.childNodes[off] || null, w = document.createTreeWalker(ROOT, NodeFilter.SHOW_TEXT), t;
      if (child) { w.currentNode = child; t = child.nodeType === 3 ? child : w.nextNode(); } else { w.currentNode = node; t = null; var last = node; while (last.lastChild) last = last.lastChild; w.currentNode = last; t = w.nextNode(); }
      if (!t) return map.length ? map[map.length - 1].end : 0;
      node = t; off = 0;
    }
    for (var i = 0; i < map.length; i++) if (map[i].node === node) return map[i].start + Math.min(off, node.nodeValue.length);
    return -1;
  }
  function anchorFromRange(r) {
    var map = textNodes(), s = offsetOf(map, r.startContainer, r.startOffset), e = offsetOf(map, r.endContainer, r.endOffset);
    if (s < 0 || e < 0 || e <= s) return null;
    var t = fullText(map), q = t.slice(s, e);
    if (!q.trim()) return null;
    if (q.length > MAXQ) { q = q.slice(0, MAXQ); e = s + MAXQ; }
    return { quote: q, prefix: t.slice(Math.max(0, s - CTX), s), suffix: t.slice(e, e + CTX) };
  }
  function locate(t, n) {
    if (!n.quote) return null;
    var best = null, bestScore = -1, i = t.indexOf(n.quote);
    while (i !== -1) {
      var sc = 0, p = n.prefix || '', s = n.suffix || '', k;
      for (k = 1; k <= p.length && t[i - k] === p[p.length - k]; k++) sc++;
      for (k = 0; k < s.length && t[i + n.quote.length + k] === s[k]; k++) sc++;
      if (sc > bestScore) { bestScore = sc; best = i; }
      i = t.indexOf(n.quote, i + 1);
    }
    return best == null ? null : [best, best + n.quote.length];
  }

  // ---------- paint marks ----------
  function unwrapAll() {
    var ms = ROOT.querySelectorAll('mark.vvm'), parents = [];
    for (var i = 0; i < ms.length; i++) { var m = ms[i], p = m.parentNode; while (m.firstChild) p.insertBefore(m.firstChild, m); p.removeChild(m); parents.push(p); }
    parents.forEach(function (p) { p.normalize(); });
  }
  var orphans = [];
  function paint() {
    if (editing || DEAD) return;
    var sel = window.getSelection(); if (sel && !sel.isCollapsed && ROOT.contains(sel.anchorNode)) { paintLater = true; return; }
    unwrapAll();
    var map = textNodes(), t = fullText(map), spans = []; orphans = [];
    Object.keys(notes).forEach(function (id) { var n = notes[id]; if (!n.quote) return; var r = locate(t, n); if (r) spans.push({ s: r[0], e: r[1], id: id, n: n }); else orphans.push(n); });
    if (!spans.length) { renderPanel(); return; }
    var cuts = {}; spans.forEach(function (x) { cuts[x.s] = 1; cuts[x.e] = 1; });
    var cutList = Object.keys(cuts).map(Number).sort(function (a, b) { return a - b; });
    map.forEach(function (m) {
      var inner = cutList.filter(function (c) { return c > m.start && c < m.end; });
      var pts = [m.start].concat(inner, [m.end]), node = m.node, base = m.start, pieces = [];
      for (var i = pts.length - 2; i >= 0; i--) {     // split from the end so offsets stay valid
        var a = pts[i], b = pts[i + 1];
        if (i > 0) { var tail = node.splitText(a - base); pieces.unshift({ node: tail, s: a, e: b }); } else pieces.unshift({ node: node, s: a, e: b });
      }
      pieces.forEach(function (pc) {
        var cov = spans.filter(function (x) { return x.s <= pc.s && x.e >= pc.e; });
        if (!cov.length || !pc.node.nodeValue) return;
        var mk = document.createElement('mark');
        var hl = cov.some(function (x) { return x.n.hl; }), cm = cov.some(function (x) { return x.n.body; });
        mk.className = 'vvm' + (hl ? ' vvm-hl' : '') + (cm ? ' vvm-cm' : '');
        mk.setAttribute('data-ids', cov.map(function (x) { return x.id; }).join(' '));
        if (cm) mk.title = '코멘트가 있음';
        pc.node.parentNode.insertBefore(mk, pc.node); mk.appendChild(pc.node);
      });
    });
    renderPanel();
  }
  var paintLater = false, paintTimer = null;
  function schedulePaint() { clearTimeout(paintTimer); paintTimer = setTimeout(paint, 60); }

  // ---------- backends ----------
  function makeLocal(key, get, set) {
    return {
      key: key, mem: {},
      load: function () { try { var v = localStorage.getItem(this.key); return v ? JSON.parse(v) : {}; } catch (e) { return this.mem; } },
      save: function (all) { this.mem = all; try { localStorage.setItem(this.key, JSON.stringify(all)); } catch (e) {} },
      start: function () { set(this.load()); var self = this; try { on(window, 'storage', function (e) { if (e.key === self.key) set(self.load()); }); } catch (e) {} return Promise.resolve(); },
      put: function (n) { var all = Object.assign({}, get()); all[n.id] = n; this.save(all); set(all); return Promise.resolve(); },
      del: function (id) { var all = Object.assign({}, get()); delete all[id]; this.save(all); set(all); return Promise.resolve(); },
      label: '이 브라우저에만 저장됨'
    };
  }
  function makeShared(db, name, get, set, quiet) {
    var col = db.collection(name);
    return {
      start: function () {
        var timer = quiet ? null : setTimeout(function () { setStatus('공유 메모를 아직 불러오지 못했음. 연결을 확인하는 중임.'); }, 10000);
        col.where('page', '==', PID).onSnapshot(function (snap) {
          var next = {}; snap.docs.forEach(function (d) { var x = d.data(); if (x) { var n = Object.assign({}, x); n.id = d.id; next[d.id] = n; } });
          set(next); if (!snap.metadata || !snap.metadata.fromCache) { clearTimeout(timer); if (!quiet) setStatus(''); }
        }, function () { clearTimeout(timer); setStatus('공유 메모 연결이 끊겼음. 새로고침하면 다시 연결함.'); });
        return Promise.resolve();
      },
      put: function (n) { var body = Object.assign({}, n); delete body.id; var all = Object.assign({}, get()); all[n.id] = n; set(all); return col.doc(n.id).set(body).catch(fail); },
      del: function (id) { var all = Object.assign({}, get()); delete all[id]; set(all); return col.doc(id).delete().catch(fail); },
      label: '공유 저장 · 실시간 반영'
    };
  }
  function setNotes(x) { if (DEAD) return; notes = x; schedulePaint(); }
  function getNotes() { return notes; }
  function setEdits(x) { if (DEAD) return; edits = x; applyEdits(); }
  function getEdits() { return edits; }
  var local = makeLocal('vvnotes:' + PID, getNotes, setNotes);
  var elocal = makeLocal('vvedits:' + PID, getEdits, setEdits);
  function fail(err) {
    var code = err && err.code;
    if (code === 'invalid_argument') { readOnly = true; setStatus('이 계정은 보기 권한이라 메모를 저장할 수 없음.'); }
    else if (code === 'quota_exceeded') setStatus('저장 공간이 가득 찼음. 오래된 메모를 지운 뒤 다시 시도할 것.');
    else setStatus('저장하지 못했음. 잠시 뒤 다시 시도할 것.');
    renderPanel();
  }

  // ---------- note operations ----------
  function now() { return Date.now(); }
  function create(anchor, opts) {
    if (readOnly || !store) return;
    anchor = anchor || { quote: '', prefix: '', suffix: '' };
    var n = { id: uid(), page: PID, quote: anchor.quote, prefix: anchor.prefix, suffix: anchor.suffix, hl: !!opts.hl, body: opts.body || '', author: me.id || null, created: now(), updated: now() };
    return store.put(n).then(function () { return n; });
  }
  function patch(id, fields) { var n = notes[id]; if (!n || readOnly) return; var m = Object.assign({}, n, fields, { updated: now() }); return store.put(m); }
  function removeHighlight(id) { var n = notes[id]; if (!n) return; return n.body ? patch(id, { hl: false }) : store.del(id); }
  function removeComment(id) { var n = notes[id]; if (!n) return; return n.hl ? patch(id, { body: '' }) : store.del(id); }

  // ---------- UI: selection toolbar ----------
  var bar = el('div', 'vv-ui vv-bar'); bar.hidden = true;
  var pendingAnchor = null;
  bar.appendChild(btn('하이라이트', 'vv-b-hl', function () { if (pendingAnchor) create(pendingAnchor, { hl: true }); clearSel(); }));
  bar.appendChild(btn('코멘트', 'vv-b-cm', function () { var a = pendingAnchor; clearSel(); if (a) openComposer(a); }));
  document.body.appendChild(bar);
  function clearSel() { pendingAnchor = null; bar.hidden = true; try { window.getSelection().removeAllRanges(); } catch (e) {} if (paintLater) { paintLater = false; schedulePaint(); } }
  function onSelect() {
    var s = window.getSelection();
    if (!s || s.isCollapsed || !s.rangeCount) { bar.hidden = true; if (paintLater) { paintLater = false; schedulePaint(); } return; }
    var r = s.getRangeAt(0);
    if (!ROOT.contains(r.commonAncestorContainer) || isUI(r.commonAncestorContainer)) { bar.hidden = true; return; }
    if (readOnly || !store || editing) { bar.hidden = true; return; }
    var a = anchorFromRange(r); if (!a) { bar.hidden = true; return; }
    pendingAnchor = a;
    var rc = r.getBoundingClientRect();
    bar.hidden = false;
    var x = Math.max(8, Math.min(window.innerWidth - bar.offsetWidth - 8, rc.left + rc.width / 2 - bar.offsetWidth / 2));
    var y = rc.top - bar.offsetHeight - 8; if (y < 64) y = rc.bottom + 8;
    bar.style.left = (x + window.scrollX) + 'px'; bar.style.top = (y + window.scrollY) + 'px';
  }
  on(document, 'mouseup', function (e) { if (bar.contains(e.target)) return; if (isInUI(e.target)) { bar.hidden = true; return; } setTimeout(onSelect, 0); });
  function isInUI(t) { return !!(t && t.closest && t.closest('.vv-ui')); }
  on(document, 'keyup', function (e) { if (e.shiftKey || e.key === 'Shift') setTimeout(onSelect, 0); });
  on(document, 'keydown', function (e) { if (e.key === 'Escape') { clearSel(); closePop(); } });

  // ---------- UI: popover on a mark ----------
  var pop = el('div', 'vv-ui vv-pop'); pop.hidden = true; document.body.appendChild(pop);
  function closePop() { pop.hidden = true; pop.textContent = ''; }
  function placePop(rc) {
    pop.hidden = false;
    var x = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 8, rc.left));
    var y = rc.bottom + 8; if (y + pop.offsetHeight > window.innerHeight - 8) y = Math.max(64, rc.top - pop.offsetHeight - 8);
    pop.style.left = (x + window.scrollX) + 'px'; pop.style.top = (y + window.scrollY) + 'px';
  }
  function noteView(n, ctx) {
    var box = el('div', 'vv-note');
    if (n.quote) {
      var q = el('p', 'vv-q', '“' + (n.quote.length > 90 ? n.quote.slice(0, 90) + '…' : n.quote) + '”');
      if (ctx === 'panel') { q.classList.add('vv-q-link'); q.addEventListener('click', function () { jump(n.id); }); }
      box.appendChild(q);
    }
    var who = n.author ? (names[n.author] || (n.author === me.id ? '나' : '')) : '';
    var meta = el('p', 'vv-meta', [n.quote ? '' : '페이지 메모', n.hl ? '하이라이트' : '', n.body && n.quote ? '코멘트' : '', who, fmt(n.updated || n.created) + (n.updated && n.created && n.updated - n.created > 1000 ? ' (수정됨)' : '')].filter(Boolean).join(' · '));
    box.appendChild(meta);
    if (n.body) box.appendChild(el('p', 'vv-body', n.body));
    if (!readOnly && store) {
      var acts = el('div', 'vv-acts');
      if (n.body) {
        acts.appendChild(btn('수정', '', function () { editInto(box, n); }));
        acts.appendChild(btn(n.quote ? '코멘트 삭제' : '삭제', 'vv-danger', function () { confirmInto(acts, n.quote ? '코멘트를 지울까요?' : '메모를 지울까요?', function () { removeComment(n.id); if (ctx === 'pop') closePop(); }); }));
      } else {
        acts.appendChild(btn('코멘트 달기', '', function () { editInto(box, n); }));
      }
      if (n.quote) {
        if (n.hl) acts.appendChild(btn('하이라이트 지우기', 'vv-danger', function () { removeHighlight(n.id); if (ctx === 'pop') closePop(); }));
        else acts.appendChild(btn('하이라이트', '', function () { patch(n.id, { hl: true }); }));
      }
      box.appendChild(acts);
    }
    return box;
  }
  function confirmInto(acts, msg, yes) {
    acts.textContent = '';
    acts.appendChild(el('span', 'vv-ask', msg));
    acts.appendChild(btn('지우기', 'vv-danger', yes));
    acts.appendChild(btn('취소', '', function () { renderPanel(); if (!pop.hidden) closePop(); }));
  }
  function editor(initial, onSave, onCancel) {
    var f = el('div', 'vv-edit'), ta = el('textarea', 'vv-ta'); ta.value = initial || ''; ta.rows = 3; ta.placeholder = '내용 입력 (Ctrl+Enter 저장)';
    var acts = el('div', 'vv-acts');
    function save() { var v = ta.value.trim(); if (!v) { ta.focus(); return; } onSave(v); }
    acts.appendChild(btn('저장', 'vv-primary', save)); acts.appendChild(btn('취소', '', onCancel));
    ta.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); save(); } if (e.key === 'Escape') { e.stopPropagation(); onCancel(); } });
    f.appendChild(ta); f.appendChild(acts); setTimeout(function () { ta.focus(); }, 0); return f;
  }
  function editInto(box, n) {
    box.textContent = '';
    if (n.quote) box.appendChild(el('p', 'vv-q', '“' + (n.quote.length > 90 ? n.quote.slice(0, 90) + '…' : n.quote) + '”'));
    box.appendChild(editor(n.body, function (v) { patch(n.id, { body: v }); closePop(); }, function () { closePop(); renderPanel(); }));
  }
  function openComposer(anchor, from) {
    pop.textContent = '';
    pop.appendChild(el('p', 'vv-q', '“' + (anchor.quote.length > 90 ? anchor.quote.slice(0, 90) + '…' : anchor.quote) + '”'));
    pop.appendChild(editor('', function (v) { create(anchor, { hl: false, body: v }); pendingAnchor = null; closePop(); }, closePop));
    var rc = (from || bar).getBoundingClientRect();
    if (from) { pop.hidden = false; pop.style.left = (Math.max(8, rc.right - pop.offsetWidth) + window.scrollX) + 'px'; pop.style.top = (Math.max(8, rc.top - pop.offsetHeight - 8) + window.scrollY) + 'px'; }
    else placePop({ left: rc.left, bottom: rc.bottom, top: rc.top });
  }
  on(ROOT, 'click', function (e) {
    if (editing && e.target.closest && e.target.closest('[contenteditable="true"] a')) { e.preventDefault(); return; }
    var m = e.target.closest ? e.target.closest('mark.vvm') : null;
    if (!m || (e.target.closest && e.target.closest('a[href]'))) return;
    var s = window.getSelection(); if (s && !s.isCollapsed) return;
    e.preventDefault();
    var ids = (m.getAttribute('data-ids') || '').split(' ').filter(function (i) { return notes[i]; });
    if (!ids.length) return;
    pop.textContent = '';
    ids.forEach(function (id) { pop.appendChild(noteView(notes[id], 'pop')); });
    placePop(m.getBoundingClientRect());
  });
  on(document, 'mousedown', function (e) { if (!pop.hidden && !pop.contains(e.target) && !dock.contains(e.target) && !(e.target.closest && e.target.closest('mark.vvm'))) closePop(); });

  // ---------- UI: side panel ----------
  var dock = el('div', 'vv-ui vv-dock');
  var dockMsg = el('p', 'vv-dock-msg', '본문 글자를 드래그한 뒤 하이라이트·코멘트를 누를 것'); dockMsg.hidden = true;
  function selAnchor() {
    var s = window.getSelection(); if (!s || s.isCollapsed || !s.rangeCount) return null;
    var r = s.getRangeAt(0); if (!ROOT.contains(r.commonAncestorContainer) || isUI(r.commonAncestorContainer)) return null;
    return anchorFromRange(r);
  }
  function needSel() { dockMsg.hidden = false; clearTimeout(needSel.t); needSel.t = setTimeout(function () { dockMsg.hidden = true; }, 3000); }
  var dHl = btn('하이라이트', 'vv-b-hl', function () { if (editing) return; var a = pendingAnchor || selAnchor(); if (!a) return needSel(); create(a, { hl: true }); clearSel(); });
  var dCm = btn('코멘트', 'vv-b-cm', function () { if (editing) return; var a = pendingAnchor || selAnchor(); if (!a) return needSel(); clearSel(); pendingAnchor = a; openComposer(a, dock); });
  var dEd = btn('본문 편집', 'vv-b-ed', function () { setEditing(!editing); });
  var fab = btn('메모 0', 'vv-primary', function () { togglePanel(panel.hidden); }); fab.setAttribute('aria-expanded', 'false');
  [dHl, dCm, dEd].forEach(function (b) { b.addEventListener('mousedown', function (e) { e.preventDefault(); }); });
  dock.appendChild(dockMsg); dock.appendChild(dHl); dock.appendChild(dCm); dock.appendChild(dEd); dock.appendChild(fab);
  var panel = el('aside', 'vv-ui vv-panel'); panel.hidden = true; panel.setAttribute('aria-label', '이 페이지의 메모');
  var head = el('div', 'vv-ph'); head.appendChild(el('strong', '', '이 페이지의 메모'));
  var io = el('div', 'vv-io');
  io.appendChild(btn('내보내기', '', exportAll));
  io.appendChild(btn('가져오기', '', function () { fileIn.click(); }));
  var fileIn = el('input'); fileIn.type = 'file'; fileIn.accept = 'application/json,.json'; fileIn.hidden = true;
  fileIn.addEventListener('change', function () { var f = fileIn.files && fileIn.files[0]; if (f) importAll(f); fileIn.value = ''; });
  head.appendChild(btn('닫기', '', function () { togglePanel(false); }));
  var status = el('p', 'vv-status'), hint = el('p', 'vv-hint', '하이라이트·코멘트: 본문 글자를 드래그한 뒤 버튼을 누름. 페이지 메모: 아래 ‘새 메모’. 본문 수정: 오른쪽 아래 ‘본문 편집’을 켜고 문단을 고치면 자동 저장됨.');
  var list = el('div', 'vv-list');
  panel.appendChild(head); panel.appendChild(status); panel.appendChild(io); panel.appendChild(fileIn); panel.appendChild(hint); panel.appendChild(list);
  document.body.appendChild(dock); document.body.appendChild(panel);
  function togglePanel(open) { panel.hidden = !open; fab.setAttribute('aria-expanded', open ? 'true' : 'false'); if (open) renderPanel(); }
  var statusMsg = '';
  function setStatus(m) { statusMsg = m; renderPanel(); }
  function order() {
    var marks = ROOT.querySelectorAll('mark.vvm'), seen = {}, out = [];
    for (var i = 0; i < marks.length; i++) (marks[i].getAttribute('data-ids') || '').split(' ').forEach(function (id) { if (id && notes[id] && !seen[id]) { seen[id] = 1; out.push(notes[id]); } });
    return out;
  }
  function renderPanel() {
    var all = Object.keys(notes).length + Object.keys(edits).length;
    fab.textContent = '메모 ' + all;
    dEd.textContent = editing ? '편집 끝내기' : '본문 편집';
    dEd.classList.toggle('vv-on', editing);
    var canWrite = !readOnly && !!store;
    io.hidden = store !== local;
    dHl.hidden = dCm.hidden = !canWrite; dEd.hidden = !canWrite || !estore;
    if (panel.hidden) return;
    status.textContent = (store ? store.label : '불러오는 중…') + (readOnly ? ' · 보기 전용' : '') + (statusMsg ? ' · ' + statusMsg : '');
    list.textContent = '';
    if (canWrite) {
      var add = el('div', 'vv-addnote');
      add.appendChild(btn('새 메모', '', function () { add.textContent = ''; add.appendChild(editor('', function (v) { create(null, { hl: false, body: v }); renderPanel(); }, renderPanel)); }));
      list.appendChild(add);
    }
    var pageNotes = Object.keys(notes).map(function (k) { return notes[k]; }).filter(function (n) { return !n.quote; }).sort(function (a, b) { return (a.created || 0) - (b.created || 0); });
    var ord = order();
    var applied = [], stale = [];
    Object.keys(edits).forEach(function (k) { var e = edits[k]; (BLOCKS[e.idx] && e.sig === OSIG[e.idx] ? applied : stale).push(e); });
    applied.sort(function (a, b) { return a.idx - b.idx; });
    if (!pageNotes.length && !ord.length && !orphans.length && !applied.length && !stale.length) list.appendChild(el('p', 'vv-empty', '아직 메모가 없음.'));
    if (pageNotes.length) { list.appendChild(el('p', 'vv-sub', '페이지 메모 ' + pageNotes.length + '건')); pageNotes.forEach(function (n) { list.appendChild(noteView(n, 'panel')); }); }
    if (ord.length) { list.appendChild(el('p', 'vv-sub', '하이라이트·코멘트 ' + ord.length + '건')); ord.forEach(function (n) { list.appendChild(noteView(n, 'panel')); }); }
    if (applied.length) { list.appendChild(el('p', 'vv-sub', '본문 수정 ' + applied.length + '건')); applied.forEach(function (e) { list.appendChild(editView(e, true)); }); }
    if (orphans.length) {
      list.appendChild(el('p', 'vv-sub', '본문에서 위치를 찾지 못한 메모 ' + orphans.length + '건 (내용이 바뀌었을 수 있음)'));
      orphans.forEach(function (n) { list.appendChild(noteView(n, 'panel')); });
    }
    if (stale.length) { list.appendChild(el('p', 'vv-sub', '적용하지 못한 본문 수정 ' + stale.length + '건 (원래 문단이 바뀌었음)')); stale.forEach(function (e) { list.appendChild(editView(e, false)); }); }
    resolveNames();
  }
  function editView(e, ok) {
    var box = el('div', 'vv-note');
    var tmp = document.createElement('div'); tmp.innerHTML = sanitize(e.html); var txt = tmp.textContent.replace(/\s+/g, ' ').trim();
    var q = el('p', 'vv-q', '“' + (txt.length > 90 ? txt.slice(0, 90) + '…' : txt) + '”');
    if (ok) { q.classList.add('vv-q-link'); q.addEventListener('click', function () { var b = BLOCKS[e.idx]; if (b) { b.scrollIntoView({ behavior: 'smooth', block: 'center' }); b.classList.add('vv-flash-b'); setTimeout(function () { b.classList.remove('vv-flash-b'); }, 1600); } }); }
    box.appendChild(q);
    var who = e.author ? (names[e.author] || (e.author === me.id ? '나' : '')) : '';
    box.appendChild(el('p', 'vv-meta', ['본문 수정', who, fmt(e.updated)].filter(Boolean).join(' · ')));
    if (!readOnly && estore) {
      var acts = el('div', 'vv-acts');
      acts.appendChild(btn(ok ? '원래대로' : '지우기', 'vv-danger', function () { confirmInto(acts, ok ? '원래 문장으로 되돌릴까요?' : '이 수정을 지울까요?', function () { estore.del(e.id); }); }));
      box.appendChild(acts);
    }
    return box;
  }
  var resolving = false;
  function resolveNames() {
    if (!userNs || resolving) return;
    var ids = Object.keys(notes).map(function (k) { return notes[k].author; }).concat(Object.keys(edits).map(function (k) { return edits[k].author; })).filter(function (a, i, arr) { return a && !(a in names) && arr.indexOf(a) === i; });
    if (!ids.length) return;
    resolving = true;
    userNs.profiles(ids).then(function (ps) { ids.forEach(function (i) { names[i] = (ps[i] && ps[i].name) || '작성자'; }); resolving = false; renderPanel(); }, function () { resolving = false; });
  }
  function jump(id) {
    var m = ROOT.querySelector('mark.vvm[data-ids~="' + id + '"]'); if (!m) return;
    m.scrollIntoView({ behavior: 'smooth', block: 'center' });
    var ms = ROOT.querySelectorAll('mark.vvm[data-ids~="' + id + '"]');
    for (var i = 0; i < ms.length; i++) { ms[i].classList.add('vvm-flash'); (function (x) { setTimeout(function () { x.classList.remove('vvm-flash'); }, 1600); })(ms[i]); }
  }

  // ---------- export / import (all pages, this browser) ----------
  function exportAll() {
    var data = {};
    try { for (var i = 0; i < localStorage.length; i++) { var k = localStorage.key(i); if (/^vv(notes|edits):/.test(k)) data[k] = JSON.parse(localStorage.getItem(k) || '{}'); } } catch (e) {}
    var blob = new Blob([JSON.stringify({ app: 'vv-red-dot-research', version: 1, exported: new Date().toISOString(), data: data }, null, 1)], { type: 'application/json' });
    var a = document.createElement('a'), d = new Date();
    a.href = URL.createObjectURL(blob); a.download = 'vv-notes-' + d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0') + '.json';
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 0);
  }
  function importAll(file) {
    var r = new FileReader();
    r.onload = function () {
      var n = 0;
      try {
        var j = JSON.parse(r.result), data = j && j.data;
        if (!data || typeof data !== 'object') throw new Error('format');
        Object.keys(data).forEach(function (k) {
          if (!/^vv(notes|edits):[\w-]+$/.test(k) || !data[k] || typeof data[k] !== 'object') return;
          var cur = {}; try { cur = JSON.parse(localStorage.getItem(k) || '{}') || {}; } catch (e) {}
          Object.keys(data[k]).forEach(function (id) {
            var x = data[k][id]; if (!x || typeof x !== 'object') return;
            if (!cur[id] || (x.updated || 0) > (cur[id].updated || 0)) { cur[id] = x; n++; }
          });
          localStorage.setItem(k, JSON.stringify(cur));
        });
        if (store === local) { setNotes(local.load()); setEdits(elocal.load()); }
        setStatus('가져오기 완료: ' + n + '건 반영');
      } catch (e) { setStatus('가져오기 실패: vv-notes JSON 파일이 아님'); }
    };
    r.readAsText(file);
  }

  // ---------- body edit mode ----------
  function eid(idx) { return PID.replace(/[^\w-]/g, '_') + '__b' + idx; }
  function applyEdits() {
    var by = {}; Object.keys(edits).forEach(function (k) { var e = edits[k]; if (BLOCKS[e.idx] && e.sig === OSIG[e.idx]) by[e.idx] = e; });
    var changed = false;
    BLOCKS.forEach(function (b, i) {
      if (editing && document.activeElement === b) return;
      var want = by[i] ? sanitize(by[i].html) : ORIG[i];
      var was = b.classList.contains('vv-edited');
      if (!by[i] && !was) return;
      if (sanitize(b.innerHTML) !== want) { b.innerHTML = want; changed = true; }
      b.classList.toggle('vv-edited', !!by[i]);
      if (was !== !!by[i]) changed = true;
    });
    if (changed) schedulePaint(); else renderPanel();
  }
  function saveBlock(i) {
    if (!estore || readOnly) return;
    var b = BLOCKS[i], html = sanitize(b.innerHTML), id = eid(i), cur = edits[id];
    if (html === ORIG[i]) { if (cur) estore.del(id); b.classList.remove('vv-edited'); return; }
    if (cur && sanitize(cur.html) === html) return;
    b.classList.add('vv-edited');
    estore.put({ id: id, page: PID, idx: i, sig: OSIG[i], html: html, author: me.id || null, updated: now() });
  }
  function onBlockKey(e) {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); document.execCommand('insertLineBreak'); }
    if (e.key === 'Escape') { e.preventDefault(); this.blur(); }
  }
  function onBlockPaste(e) { e.preventDefault(); var tx = (e.clipboardData || window.clipboardData).getData('text/plain'); document.execCommand('insertText', false, tx); }
  function onBlockBlur() { var i = BLOCKS.indexOf(this); if (i >= 0) saveBlock(i); }
  function setEditing(on) {
    if (on === editing || (on && (readOnly || !estore))) return;
    if (on) {
      clearSel(); closePop(); unwrapAll(); editing = true;
      BLOCKS.forEach(function (b) { b.setAttribute('contenteditable', 'true'); b.setAttribute('spellcheck', 'false'); b.addEventListener('keydown', onBlockKey); b.addEventListener('paste', onBlockPaste); b.addEventListener('blur', onBlockBlur); });
      document.body.classList.add('vv-editing');
      dockMsg.textContent = '문단을 눌러 고치면 자동 저장됨. Esc 또는 ‘편집 끝내기’로 마침.'; dockMsg.hidden = false; clearTimeout(needSel.t); needSel.t = setTimeout(function () { dockMsg.hidden = true; dockMsg.textContent = '본문 글자를 드래그한 뒤 하이라이트·코멘트를 누를 것'; }, 4000);
    } else {
      if (document.activeElement && BLOCKS.indexOf(document.activeElement) >= 0) document.activeElement.blur();
      BLOCKS.forEach(function (b) { b.removeAttribute('contenteditable'); b.removeAttribute('spellcheck'); b.removeEventListener('keydown', onBlockKey); b.removeEventListener('paste', onBlockPaste); b.removeEventListener('blur', onBlockBlur); });
      document.body.classList.remove('vv-editing'); editing = false; applyEdits(); schedulePaint();
    }
    renderPanel();
  }

  // ---------- start ----------
  renderPanel();
  function waitClaude(cb) {
    if (window.VV_STANDALONE) return cb(null);
    var t0 = Date.now();
    (function poll() {
      if (window.claude && typeof window.claude.use === 'function') return cb(window.claude);
      if (Date.now() - t0 > 3000) return cb(null);
      setTimeout(poll, 100);
    })();
  }
  function startLocal() { if (store) return; store = local; estore = elocal; store.start(); estore.start(); renderPanel(); }
  var startedLocal = false;
  var fallback = setTimeout(function () { if (!store) { startedLocal = true; startLocal(); } }, 4500);
  waitClaude(function (cl) {
    var useP = cl ? cl.use('db') : Promise.resolve(null);
    Promise.resolve(useP).then(function (db) {
      if (!db) { clearTimeout(fallback); startLocal(); return; }
      clearTimeout(fallback);
      var carryN = startedLocal ? local.load() : {}, carryE = startedLocal ? elocal.load() : {};
      store = makeShared(db, 'notes', getNotes, setNotes, false);
      estore = makeShared(db, 'edits', getEdits, setEdits, true);
      if (startedLocal) { notes = {}; edits = {}; }
      store.start(); estore.start();
      Object.keys(carryN).forEach(function (k) { store.put(carryN[k]); });
      Object.keys(carryE).forEach(function (k) { estore.put(carryE[k]); });
      if (Object.keys(carryN).length) local.save({});
      if (Object.keys(carryE).length) elocal.save({});
      var up = cl.use('user');
      Promise.resolve(up).then(function (u) {
        if (!u) return; userNs = u;
        u.me().then(function (m) { me.id = m.id; if (m.id) names[m.id] = m.name || '나'; renderPanel(); });
        u.can('data.write').then(function (c) { if (c === false) { readOnly = true; setEditing(false); renderPanel(); } });
      });
      renderPanel();
    }, function () { clearTimeout(fallback); startLocal(); });
  });
  return {
    destroy: function () {
      if (DEAD) return;
      setEditing(false); clearSel(); closePop(); clearTimeout(paintTimer); clearTimeout(fallback); DEAD = true; unwrapAll();
      LISTEN.forEach(function (x) { x[0].removeEventListener(x[1], x[2], x[3]); });
      [bar, pop, dock, panel].forEach(function (n) { if (n && n.parentNode) n.parentNode.removeChild(n); });
    }
  };
};
