/* Hash router: #/<page>/<anchor>. Keeps one page section visible and re-binds the notes tool to it. */
(function () {
  'use strict';
  window.VV_STANDALONE = true;
  var SITE = 'VV Red Dot Research';
  var pages = {}, cur = null, notes = null;
  Array.prototype.forEach.call(document.querySelectorAll('section.page'), function (s) { pages[s.getAttribute('data-key')] = s; });
  var links = document.querySelectorAll('.tree a');
  function markNav(key) {
    var href = key === 'index' ? '#/' : '#/' + key;
    Array.prototype.forEach.call(links, function (a) { a.removeAttribute('aria-current'); });
    Array.prototype.forEach.call(document.querySelectorAll('.tree'), function (tree) {
      var subs = tree.querySelectorAll(':scope > li > ul a[href="' + href + '"]');
      var hits = subs.length ? subs : tree.querySelectorAll('a[href="' + href + '"]');
      Array.prototype.forEach.call(hits, function (a) { a.setAttribute('aria-current', 'page'); });
    });
    try {
      var r = document.querySelector('.rail'), c = r && r.querySelector('a[aria-current]');
      if (c) { var a = c.getBoundingClientRect(), b = r.getBoundingClientRect(); if (a.bottom > b.bottom || a.top < b.top) r.scrollTop += a.top - b.top - b.height / 3; }
    } catch (e) {}
  }
  function jumpTo(el) {
    var h = document.documentElement, prev = h.style.scrollBehavior;
    h.style.scrollBehavior = 'auto';
    void h.offsetHeight;
    try { if (el) el.scrollIntoView({ behavior: 'instant', block: 'start' }); else window.scrollTo({ top: 0, left: 0, behavior: 'instant' }); }
    catch (e) { if (el) el.scrollIntoView(); else window.scrollTo(0, 0); }
    h.style.scrollBehavior = prev;
  }
  function show(key) {
    if (cur === key) return false;
    Object.keys(pages).forEach(function (k) { pages[k].hidden = k !== key; });
    var s = pages[key];
    document.title = s.getAttribute('data-title') || SITE;
    if (notes) notes.destroy();
    notes = window.VVAnnot ? window.VVAnnot(s, s.getAttribute('data-page')) : null;
    markNav(key); cur = key;
    var m = document.querySelector('.mnav-all'); if (m) m.open = false;
    return true;
  }
  function route() {
    var h = decodeURIComponent(location.hash.replace(/^#\/?/, '')), i = h.indexOf('/');
    var key = i < 0 ? h : h.slice(0, i), anchor = i < 0 ? '' : h.slice(i + 1);
    if (!pages[key]) key = 'index';
    var changed = show(key);
    var el = anchor ? document.getElementById(key + '--' + anchor) : null;
    if (el) { if (changed) jumpTo(el); else el.scrollIntoView({ behavior: 'smooth' }); }
    else if (changed) jumpTo(null);
  }
  window.addEventListener('hashchange', route);
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('a[href^="#/"]');
    if (a && a.getAttribute('href') === location.hash) { e.preventDefault(); route(); }
  });
  route();
})();
