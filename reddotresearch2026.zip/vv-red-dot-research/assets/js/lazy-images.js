(function () {
  var els = document.querySelectorAll('.spr[data-bg]');
  function show(e) { var u = e.getAttribute('data-bg'); if (u) { e.style.backgroundImage = 'url("' + u + '")'; e.removeAttribute('data-bg'); } }
  if (!('IntersectionObserver' in window)) { for (var i = 0; i < els.length; i++) show(els[i]); return; }
  var io = new IntersectionObserver(function (es) { es.forEach(function (en) { if (en.isIntersecting) { show(en.target); io.unobserve(en.target); } }); }, { rootMargin: '600px 0px' });
  for (var j = 0; j < els.length; j++) io.observe(els[j]);
  window.addEventListener('beforeprint', function () { for (var k = 0; k < els.length; k++) show(els[k]); });
})();
