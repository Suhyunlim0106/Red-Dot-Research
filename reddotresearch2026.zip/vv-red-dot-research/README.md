# VV Red Dot Research

레드닷 Brands & Communication Design·Design Concept 카테고리와 수상작, 시각도구연구실(VV) 프로젝트별 수상작 아카이브를 정리한 정적 웹사이트.

## 구성

```
index.html                 사이트 전체(12개 페이지와 CSS를 한 파일에 담고 #/주소로 전환)
assets/js/router.js        페이지 전환(#/bc, #/vv-id40/ucmp 등)
assets/js/notes.js         하이라이트·코멘트·페이지 메모·본문 편집
assets/js/lazy-images.js   이미지 지연 로딩
assets/img/                카드 이미지(*.jpg)
assets/img/p/              프로젝트별 이미지 묶음(스프라이트)
assets/fonts/              Pretendard Variable(SIL OFL 1.1)
.nojekyll                  GitHub Pages의 Jekyll 처리 끄기
```

모든 경로는 상대 경로라 저장소 루트나 하위 폴더 어디에 두어도 동작함.

## GitHub Pages에 올리기

1. GitHub에서 새 저장소를 만듦(예: `vv-red-dot-research`).
2. 이 폴더 안의 파일 전체(`index.html`, `assets/`, `.nojekyll`, `README.md`)를 저장소 루트에 올림.
   - 웹에서 올릴 때: 저장소의 **Add file → Upload files**에 폴더 내용을 끌어다 놓음. `.nojekyll`처럼 점으로 시작하는 파일이 빠지지 않았는지 확인.
   - 명령어로 올릴 때:
     ```
     git init
     git add .
     git commit -m "VV Red Dot Research"
     git branch -M main
     git remote add origin https://github.com/<계정>/<저장소>.git
     git push -u origin main
     ```
3. 저장소 **Settings → Pages**에서 Source를 **Deploy from a branch**, Branch를 **main / (root)**로 저장.
4. 1~2분 뒤 `https://<계정>.github.io/<저장소>/`에서 열림.

올리기 전에 내 컴퓨터에서 보려면 이 폴더에서 `python3 -m http.server`를 실행하고 `http://localhost:8000`을 염. `index.html`을 더블클릭해 열면 일부 브라우저가 글꼴 파일을 막아 한글이 기본 글꼴로 보일 수 있음.

## 페이지 주소

| 페이지 | 주소 |
|---|---|
| 개요 | `#/` |
| B&C | `#/bc` |
| Design Concept | `#/dc` |
| 어워드 분석 | `#/award-compare`, `#/award-rates`, `#/analysis` |
| VV 프로젝트 중심 분석 | `#/vv`, `#/vv-id-rebranding`, `#/vv-id40`, `#/vv-watch-workshop`, `#/vv-gwangju-biennale` |
| 참고 문헌 | `#/references` |

페이지 안 위치는 `#/페이지/위치`(예: `#/vv-id40/ucmp`)로 바로 열 수 있음.

## 메모·하이라이트·본문 편집

오른쪽 아래 버튼으로 씀.

- 하이라이트·코멘트: 본문 글자를 드래그한 뒤 버튼을 누름. 표시된 부분을 누르면 수정·삭제.
- 본문 편집: 켜고 문단을 고치면 자동 저장. 메모 패널의 ‘원래대로’로 되돌림.
- 페이지 메모: 메모 패널의 ‘새 메모’.

GitHub Pages는 서버 저장소가 없어 메모와 수정 내용은 **각자 브라우저에만 저장됨**(localStorage). 다른 사람·다른 기기와 나누려면 메모 패널의 **내보내기**로 JSON 파일을 받고, 상대 쪽에서 **가져오기**로 불러옴. 같은 메모는 최근에 고친 쪽이 남음.

## 글꼴

영문은 Helvetica(기기에 설치된 경우), 없으면 Arial. 한글은 함께 넣은 Pretendard로 표시됨. Helvetica는 라이선스상 파일을 포함하지 않음.
